﻿namespace EcommerceManagement.Core.Enums
{
    public enum PaymentStatus
    {
        Pending = 1,
        Successful = 2,
        Failed = 3,
    }
}
