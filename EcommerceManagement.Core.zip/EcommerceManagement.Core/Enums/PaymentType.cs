﻿namespace EcommerceManagement.Core.Enums
{
    public enum PaymentType
    {
        Payment = 1,
        Refund = 2,
    }
}
